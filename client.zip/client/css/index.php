<script type="text/javascript">
  let loc = window.location;
  if (loc.href == "https://afu.uz/client/css/") {
    window.location = "../../index"
  }
</script>