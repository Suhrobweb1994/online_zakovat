<script type="text/javascript">
  let loc = window.location;
  if (loc.href === "http://localhost/alfraganus_yangi/client/img/logo/") {
    window.location = "../../index"
  }
</script>