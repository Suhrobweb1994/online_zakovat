<script type="text/javascript">
  let loc = window.location;
  if (loc.href === "https://afu.uz/client/img/") {
    window.location = "../../index"
  }
</script>