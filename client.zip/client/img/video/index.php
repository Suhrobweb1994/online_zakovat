<script type="text/javascript">
  let loc = window.location;
  if (loc.href === "http://localhost/alfraganus_yangi/client/img/video/") {
    window.location = "../../index"
  }
</script>