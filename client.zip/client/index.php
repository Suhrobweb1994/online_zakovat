<script type="text/javascript">
  let loc = window.location;
  if (loc.href == "https:/online_zakovat/client/") {
    window.location = "../index"
  }
</script>