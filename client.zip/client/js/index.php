<script type="text/javascript">
  let loc = window.location;
  if (loc.href == "https://afu.uz/client/js/") {
    window.location = "../../index"
  }
</script>